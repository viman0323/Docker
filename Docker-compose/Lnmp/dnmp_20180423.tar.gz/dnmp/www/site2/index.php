<?php
echo 'Site 2<br />';
phpinfo();
